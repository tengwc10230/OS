#include <stdio.h>
#include <unistd.h>
#include <string.h>
#include <sys/wait.h>

#define MAX_LINE 80

int main(void)
{
	char *arg[MAX_LINE/2+1] = {}; 
	int should_run = 1; /*flag to determine when to exit program*/	
	pid_t pid;

	while(should_run){
		int status;
		char inputBuffer[MAX_LINE]={};

		printf("osh>");
		fflush(stdout);
 	  read(STDIN_FILENO, inputBuffer, MAX_LINE);
		int ccrc = 0;
		int j,k;
		for (j = 0,k = 0; inputBuffer[j] != '\0'; j++)
		{
			if (inputBuffer[j] != '&')
				inputBuffer[k++]=inputBuffer[j];
      
			else
				ccrc = 1;	
		}
		inputBuffer[k] = '\0';
		

    int i = 0;
		arg[i] = strtok(inputBuffer,"\n");
    arg[i] = strtok(inputBuffer," ");
		if(strcmp(arg[0],"exit")==0)	break;
		while (arg[i]){
			i++;
			arg[i] = strtok(NULL," ");
		}
    
		pid = fork();
	
		if (pid > 0)
    {	
        if (ccrc == 0)	pid = wait(&status);
    }
		else
			execvp(arg[0],arg); 

		

		/**:
		* your code!
		* After reading user input, the step are:
		* (1) fork a child process using fork()
		* (2) the child process will invoke execvp()
		* (3) if command included &, parent will invoke wait()
		*/
	}

	return 0;
}










