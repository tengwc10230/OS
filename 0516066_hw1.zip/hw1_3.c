#include <stdio.h>
#include <unistd.h>

int main(void)
{
	pid_t pid;
	pid = fork();	// Fork1 
	
	if (pid > 0)
	{
		//Main 
		printf("Main process id :%d.\n",getpid());
		usleep(2000);
	
	}			
	else	//Fork1 child
	{
		printf("Fork1, I'm the child %d, my parent is %d.\n",getpid(),getppid());
		pid = fork();	//Fork2
		
		if (pid == 0)//Fork2 child
			printf("Fork2, I'm the child %d, my parent is %d.\n",getpid(),getppid());
			
		else usleep(1000);			

	}		
	pid = fork();	//Fork3
	if (pid == 0)	//Fork3 child
		printf("Fork3, I'm the child %d, my parent is %d.\n",getpid(),getppid());

	return 0;
}










