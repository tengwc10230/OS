/* Multilevel Feedback Queue (RR + SJF) */
#include <iostream>
#include <fstream>
#include <queue>
#include<algorithm>
using namespace std;
int main(int argc, char **argv)
{
	fstream fin;
	fin.open(argv[1], ios::in);
	if (!fin)	cout << "file cannot read";
	else 
	{
		int num;
		fin >> num;
		int arr_time[num];
		int bur_time[num];
		int bur_time_real[num];
		int waiting[num];

		float MAX = 0;
		for (int i = 0; i < num; i ++)
			fin >> arr_time[i];
	
		for (int i = 0; i < num; i ++)
		{
			fin >> bur_time[i];
			bur_time_real[i] = bur_time[i];
			waiting[i] = 0;
			MAX += bur_time[i];
		}
		
		int slice_high;
		int slice_low;
		fin >> slice_high;
		fin >> slice_low;
		
		int pcs = num;
		int wait = 0;
		int run = 0;
		queue<int> q1;
		queue<int> q2;

	
		
		for (int time = 0; time < MAX; time ++)
		{
			for (int i = 0; i < num; i ++)
				if (arr_time[i] == time)	
					q1.push(i);	
			
			if (!q1.empty())
			{
				pcs = q1.front(); 
				
				if (bur_time[pcs] == 1) 
				{
					q1.pop();
					run = -1;
				}
				else if (run == slice_high)
				{
					q2.push(pcs);
					q1.pop();
					if (!q1.empty())
					{  
						pcs = q1.front(); 
					}
					else 
					{
						pcs = q2.front(); 
					}
	          		run = 0;
				}
				run ++;
       
			}
			else if(pcs != num && !q2.empty() )
			{
 				pcs = q2.front();
			
				if (bur_time[pcs] == 1) 
				{
					q2.pop();
					run = 0;
				}
				else if (run == slice_low)
				{
					q2.pop();
					if (!q2.empty())
					{  
						pcs = q2.front();
						run = 0; 
					}
					else 
					{
						int schd = MAX;
						for (int j = 0; j < num; j ++)
						{
							if (bur_time[j] > 0 && time >= arr_time[j])
							{
								if (bur_time[j] < schd)
								{
									pcs = j;
									schd = bur_time[j];
				    			}
					  		}
           				}
            			time += schd -1;
				    	bur_time[pcs] = 1;
				    	
            			for (int j = 0; j < num; j ++)
    					if (j != pcs && bur_time[j] > 0 && time >= arr_time[j])	
    						waiting[j] += (schd-1); 
							  
            			run = -1;
         			}
          
				}
				run ++;
        
			}
			else if(pcs != num)
			{
				
				int schd = MAX;
				for (int j = 0; j < num; j ++)
				{
					if (bur_time[j] > 0 && time >= arr_time[j])
					{
						if (bur_time[j] < schd)
						{
							pcs = j;
							schd = bur_time[j];
						}
					}
				}
				time += schd-1;
				bur_time[pcs] = 1;
				
				for (int j = 0; j < num; j ++)
					if (j != pcs && bur_time[j] > 0 && time >= arr_time[j])	
						waiting[j] += (schd-1);
				
			}
			
		
      
			for (int k = 0; k < num; k ++)
				if (k != pcs && bur_time[k] > 0 && time >= arr_time[k])	
					waiting[k] ++;
				
			bur_time[pcs] --;
			
			
		} 

		fstream fout;
		fout.open("ans4.txt", ios::out);
		if (!fout)	cout << "file cannot write";
		else
		{
			float total = 0;
			for (int i = 0; i < num; i ++)	
			{
				fout << waiting[i] << " " << waiting[i] + bur_time_real[i] << endl;
				total += waiting[i];
			}
			fout << total/num << endl;
			fout << (total + MAX)/num << endl;
		}
		
	
	}
		
} 

