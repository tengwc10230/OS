/* RR */
#include <iostream>
#include <fstream>
#include <queue>
using namespace std;
int main(int argc, char **argv)
{
	fstream fin;
	fin.open(argv[1], ios::in);
	if (!fin)	cout << "file cannot read";
	else {
		int num;
		fin >> num;
		int arr_time[num];
		int bur_time[num];
		int bur_time_real[num];
		int waiting[num];

		float MAX = 0;
		for (int i = 0; i < num; i ++)
			fin >> arr_time[i];
		
		for (int i = 0; i < num; i ++)
		{
			fin >> bur_time[i];
			bur_time_real[i] = bur_time[i];
			waiting[i] = 0;
			MAX += bur_time[i];
		}
		
		int slice;
		fin >> slice;
		
		int pcs = num;
		int wait = 0;
		int run = 0;
		queue<int> q1;
		
		for (int time = 0; time < MAX; time ++)
		{
			for (int i = 0; i < num; i ++)
				if (arr_time[i] == time)	
					q1.push(i);	
			
			if (!q1.empty())
			{
				pcs = q1.front(); 
				
				if (bur_time[pcs] == 1) 
				{
					q1.pop();
					run = 0;
				}
				else if (run == slice)
				{
					q1.push(pcs);
					q1.pop();
          			pcs = q1.front(); 
					run = 0;
				}
				run ++;
			}

			for (int j = 0; j < num; j ++)
				if (j != pcs && bur_time[j] > 0 && time >= arr_time[j])	
					++waiting[j];
			

			bur_time[pcs] --;
			
				
		} 
		
		fstream fout;
		fout.open("ans3.txt", ios::out);
		if (!fout)	cout << "file cannot write";
		else
		{
			float total = 0;
			for (int i = 0; i < num; i ++)	
			{
				fout << waiting[i] << " " << waiting[i] + bur_time_real[i] << endl;
				total += waiting[i];
			}
			fout << total/num << endl;
			fout << (total + MAX)/num << endl;
		}
		
	
	}
		
} 

