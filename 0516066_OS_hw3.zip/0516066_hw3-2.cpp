/* SRTF */
#include <iostream>
#include <fstream>
using namespace std;
int main(int argc, char **argv)
{
  	fstream fin;
  	fin.open(argv[1], ios::in);
	if (!fin)	cout << "file cannot read";
	else {
		int num;
		fin >> num;
		int arr_time[num];
		int bur_time[num];
		int bur_time_real[num];
		int waiting[num];

		float MAX = 0;
		for (int i = 0; i < num; i ++)
			fin >> arr_time[i];
		
		for (int i = 0; i < num; i ++)
		{
			fin >> bur_time[i];
			bur_time_real[i] = bur_time[i];
			waiting[i] = 0;
			MAX += bur_time[i];
		}
		
		int wait = 0;
		for (int time = 0; time < MAX; time++)
		{
			int pcs = 0;
			int schd = MAX;
			
			for (int i = 0; i < num; i ++)
			{
				if (time >= arr_time[i])
				{
					if (bur_time[i] < schd && bur_time[i] != 0)
					{
						pcs = i;
						schd = bur_time[i];
					}
						
				}
			}
			
			for (int j = 0; j < num; j ++)
				if (j != pcs && bur_time[j] > 0 && time >= arr_time[j])	waiting[j] ++;
				
			bur_time[pcs] --;
		} 
		
		fstream fout;
		fout.open("ans2.txt", ios::out);
		if (!fout)	cout << "file cannot write";
		else
		{
			float total = 0;
			for (int i = 0; i < num; i ++)	
			{
				fout << waiting[i] << " " << waiting[i] + bur_time_real[i] << endl;
				total += waiting[i];
			}
			fout << total/num << endl;
			fout << (total + MAX)/num << endl;
		}
		
	
	}
		
} 
