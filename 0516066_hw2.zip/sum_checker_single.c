#include <stdio.h>
#define PUZZLE_SIZE 9

int puzzle[PUZZLE_SIZE+1][PUZZLE_SIZE+1] = {
		{-1,-1,-1,-1,-1,-1,-1,-1,-1,-1},
		{-1,0,0,0,0,0,0,0,0,0},
		{-1,0,0,0,0,0,0,0,0,0},
		{-1,0,0,0,0,0,0,0,0,0},
		{-1,0,0,0,0,0,0,0,0,0},
		{-1,0,0,0,0,0,0,0,0,0},
		{-1,0,0,0,0,0,0,0,0,0},
		{-1,0,0,0,0,0,0,0,0,0},
		{-1,0,0,0,0,0,0,0,0,0},
		{-1,0,0,0,0,0,0,0,0,0}
	};

#define LINE "====================== \n"
#define COLLINE "\n___________________________________ \n"
#define NAME "||  SUM   CHECKER  || \n"
void print_grid(int grid[10][10])
{
    int i,j;
    printf(LINE);
    printf(NAME);
    printf(LINE);

	for (i = 1; i < 10; i++)
	{
		for (j = 1; j < 10; j++)
		{
	        printf("|%1d |",grid[i][j]);
		}
        printf(COLLINE);
	}
    printf("\n");
}
// read file to check sudoku
void SetPuzzle(char filename[]){
    FILE *file = fopen(filename,"r");
    int i,j,ch,num;
    for (i=0;i<=9;i++){
        for(j=0;j<=9;j++){
            while(((ch = getc(file)) != EOF)){
                if(ch == EOF) break;
                if(ch == ',') break;
                if(ch == '\n') break;
                ungetc(ch,file);
                fscanf(file,"%d",&num);
                if(num!=-1)
                    puzzle[i][j] = num;            
            } 
        }
    }
    print_grid(puzzle);
    return;
}

	
int main(int argc, char* argv[])
{
	int rv = 1; // flag to check answer
	// input the sudoku file
	SetPuzzle("test.txt");
	//Your code here
 
  //set sum
	int sum = 0;
  for (int k = 1; k <= 9; k ++)
      sum += puzzle[1][k];
      
	//check row
	for (int i = 1; i <= 9; i ++)
	{
      int check = 0;
      for (int j = 1; j <= 9; j ++)
      {    
          if (puzzle[i][j] > 9 || puzzle[i][j] < 1)
          {    
              rv = 0;
              break;
          }
          check += puzzle[i][j];
      }
      if (check != sum)
      {    
          rv = 0;
          break;
      }
	}
	
	//check col
	if (rv == 1)
	{
    	for (int j = 1; j <= 9; j ++)
    	{
          int check = 0;
          for (int i = 1; i <= 9; i ++)
          {    
              if (puzzle[i][j] > 9 || puzzle[i][j] < 1)
              {    
                  rv = 0;
                  break;
              }
              check += puzzle[i][j];
          }
          if (check != sum)
          {    
              rv = 0;
              break;
          }
    	}
		
	}
	
	if (rv == 1)
	{
  		for (int i = 1; i < 10; i += 3)
  		{
    			for (int j = 1; j < 10; j += 3)
    			{
    				  int check = 0;
      				for (int k = i; k < i+3; k ++)
      				{
        					for (int l = j; l < j+3; l++)
        					{
                      if (puzzle[k][l] > 9 || puzzle[k][l] < 1)
                      {
                          rv = 0;
                          break;
                      }
                      check += puzzle[k][l];
        					}
        					if (rv == 0)    break;	
      				}	
              
      				if (check != sum || rv == 0)
              {    
                  rv = 0;
                  break;
              }	
    			}
    			if (rv == 0)    break;
  		}
	}
	 
	if (rv == 1)
		printf("Successful :) \n");
	else
		printf("Must check again! :( \n");

	return 0;
	
} 
